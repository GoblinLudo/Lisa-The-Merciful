You can use the source code noncommercially or commercially, and you are free to modify and redistribute the source code as you wish.

You must credit me as "Liam" and not remove my name from the source code wherever you use or redistribute any of the source code.

You must link an original copy of the script posted by Liam if you distribute modified copies of the source code.
